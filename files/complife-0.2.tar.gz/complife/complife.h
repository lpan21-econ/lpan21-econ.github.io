#ifndef COMPLIFE_H
#define COMPLIFE_H

struct meanTrack
{
  double meank;
  meanTrack* next;
};

#endif // COMPLIFE_H

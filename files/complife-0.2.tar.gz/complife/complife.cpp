#include <stdlib.h>
#include <stdio.h>
#include <cairo/cairo.h>
#include <malloc.h>
#include <string.h>
#include <math.h>
#include <float.h>
#include <time.h>
#include <glib.h>
#include <gdk/gdk.h>
#include <gdk/gdkcairo.h>
#include <gtk/gtk.h>

#include "complife.h"

const int gridSize = 20;
const int gridWidth = 2*gridSize;
const int gridHeight = gridSize;

double cellWidth = 1.0/double(gridWidth);
double cellHeight = 1.0/double(gridHeight);

const int width = 600;
const int height = 300;

char cells[gridWidth*gridHeight];
char count[(gridWidth+2)*(gridHeight+2)];
double colors[gridWidth*gridHeight];
double newcolors[(gridWidth+2)*(gridHeight+2)];

GtkWidget* window = NULL;

int burnIn = 10000;
int meanLength = 5000;
meanTrack* mtl;
double mtVal = 2.0;
double lastmt = -1.0;

int iter = 0;

char run = 1;
guint idleID;

static gboolean expose_grid(GtkWidget* widget, GdkEventExpose* event)
{
  cairo_t *cr = gdk_cairo_create(widget->window);
  cairo_scale(cr,width,height);

  char* cellPos = cells;
  double* colorPos = colors;
  double colVal;
  for (int i = 0; i < gridHeight; i++) {
    for (int j = 0; j < gridWidth; j++) {
      if (*cellPos == 1) {
        colVal = *colorPos;
        cairo_set_source_rgba(cr,1.0-colVal,0.0,colVal,1.0);
      } else {
        cairo_set_source_rgba(cr,0.0,0.0,0.0,1.0);
      }

      cairo_rectangle(cr,double(j)*cellWidth,double(i)*cellHeight,double(j+1)*cellWidth,double(i+1)*cellHeight);
      cairo_fill(cr);

      cellPos++;
      colorPos++;
    }
  }

  cairo_destroy(cr);
  return FALSE;
}

static gboolean next_grid(void* dat)
{
  clock_t goal = 100000 + clock();
  while (goal > clock());

  if (window == NULL) return TRUE;

  int i;
  int j;
  int k;
  int q;

  char* cellPos;
  double* colorPos;
  char* countPos[8];
  double* newcolorPos[8];
  char* c1Pos;
  double* c2Pos;

  int vol = gridWidth*gridHeight;
  int cvol = (gridWidth+2)*(gridHeight+2);
  int rw = gridWidth+2;

  char incr;
  char countval;
  double colorval;

  int numCells;
  double meanColor;

  char changed = 0;

  memset(count,0,sizeof(char)*cvol);
  memset(newcolors,0,sizeof(double)*cvol);

  cellPos = cells;
  colorPos = colors;

  countPos[0] = count;
  countPos[1] = count+1;
  countPos[2] = count+2;
  countPos[3] = count+rw;
  countPos[4] = count+rw+2;
  countPos[5] = count+2*rw;
  countPos[6] = count+2*rw+1;
  countPos[7] = count+2*rw+2;

  newcolorPos[0] = newcolors;
  newcolorPos[1] = newcolors+1;
  newcolorPos[2] = newcolors+2;
  newcolorPos[3] = newcolors+rw;
  newcolorPos[4] = newcolors+rw+2;
  newcolorPos[5] = newcolors+2*rw;
  newcolorPos[6] = newcolors+2*rw+1;
  newcolorPos[7] = newcolors+2*rw+2;

  for (i = 0; i < gridHeight; i++) {
    for (j = 0; j < gridWidth; j++) {
      if (*cellPos == 1) {
        for (q = 0; q < 8; q++) {
          (*(countPos[q]))++;
          (*(newcolorPos[q])) += *colorPos;
        }
      }

      if (j == (gridWidth-1)) {
        incr = 3;
      } else { 
        incr = 1;
      }

      for (q = 0; q < 8; q++) {
        countPos[q] += incr;
        newcolorPos[q] += incr;
      }

      cellPos++;
      colorPos++;
    }
  }

  numCells = 0;
  meanColor = 0.0;
  cellPos = cells;
  colorPos = colors;
  c1Pos = count+rw+1;
  c2Pos = newcolors+rw+1;
  for (i = 0; i < gridHeight; i++) {
    for (j = 0; j < gridWidth; j++) {
      countval = *c1Pos;
      colorval = *c2Pos;

      if (*cellPos == 1) {
        if ((countval > 3) || (countval < 2)) { 
          *cellPos = 0;
          *colorPos = 0.0;
          changed = 1;
        }
      } else {
        if (countval == 3) {
          *cellPos = 1;
          *colorPos = colorval/3.0;
          changed = 1;
        }
      }

      if (*cellPos == 1) {
        numCells++;
        meanColor += *colorPos;
      }

      if (j == (gridWidth-1)) {
        incr = 3;
      } else { 
        incr = 1;
      }

      c1Pos += incr;
      c2Pos += incr;

      cellPos++;
      colorPos++;
    }
  }

  meanColor /= double(numCells);

  meanTrack* mtk = mtl;
  while ((mtk->next) != mtl) {
    mtk->meank += meanColor;
    mtk = mtk->next;
  }
  mtk->meank += meanColor;

  lastmt = mtVal;
  mtVal = (mtk->meank)/double(meanLength);

  mtk->meank = 0.0;
  mtl = mtl->next;

  printf("iter = %i, meanColor = %f, meanTrack = %f\n",iter,meanColor,mtVal);

  gdk_window_invalidate_rect(window->window,NULL,TRUE);
  //gdk_window_process_updates(window->window,TRUE);

  if (numCells == 0) {
    printf("No cells: a draw!\n");
    return FALSE;
  }

  iter++;

  if (iter < burnIn) {
    return TRUE;
  }

  if (fabs(mtVal-lastmt) < 10e-6) {
    if (mtVal < 0.5) {
      printf("Red wins!\n");
    } else if (mtVal == 0.5) {
      printf("A technical draw!\n");
    } else {
      printf("Blue wins!\n");
    }

    return FALSE;
  } else {
    return TRUE;
  }
}

static gboolean togglePause(GtkWidget* widget, GdkEventExpose* event)
{
  if (run == 1) {
    gtk_idle_remove(idleID);
    run = 0;
  } else {
    idleID = gtk_idle_add(next_grid,NULL);
    run = 1;
  }
}

int loadCells(FILE* src, char* destCell, double* destColor, int rw, int frw, double col)
{
  // Old format
  /*
  int maxLen = 2*rw+32;
  char* line = (char*)malloc(sizeof(char)*maxLen);

  char* cellRow = destCell;
  char* cellPos;
  double* colorRow = destColor;
  double* colorPos;
  char* linePos;
  while(fgets(line,maxLen,src)) {
    linePos = line;
    cellPos = cellRow;
    colorPos = colorRow;
    for (int j = 0; j < rw; j++) {
      if (*linePos == '0') {
        *cellPos = 0;
        *colorPos = 0.0;
      } else {
        *cellPos = 1;
        *colorPos = col;
      }

      linePos += 2;
      cellPos++;
      colorPos++;
    }

    cellRow += frw;
    colorRow += frw;
  }
  */

  // RLE format
  int maxLen = rw+gridSize+32;
  char* line = (char*)malloc(sizeof(char)*maxLen);
  int xbase = 0;
  int ybase = 0;
  fgets(line,maxLen,src);
  if (line[0] == '#') {
    sscanf(line,"#CXRLE Pos=%i,%i",&xbase,&ybase);
    if ((xbase < 0) || (ybase < 0)) return -1;
    fgets(line,maxLen,src);
  }

  char temp[64];
  int x;
  int y;
  sscanf(line,"x = %i, y = %i, %s",&x,&y,temp);
  if ((x > gridSize) || (y > gridSize)) return -1;

  x = 0;
  int k;
  int gap;
  char* linePos;
  char* cellPos = destCell + frw*ybase + xbase;
  double* colPos = destColor + frw*ybase + xbase;
  char cur;
  int numInd = 0;
  char num[32];
  int numVal;
  char cellVal;
  while(fgets(line,maxLen,src)) {
    linePos = line;
    while (*linePos != '\n') {
      cur = *linePos;

      if (cur == '!') {
        return 0;
      } else if ((cur == '$') || (cur == 'b') || (cur == 'o')) {
        if (numInd == 0) {
          numVal = 1;
        } else {
          num[numInd] = '\0';
          numVal = atoi(num);
        }
        numInd = 0;

        if (cur == '$') {
          cellPos += frw*numVal - x;
          colPos += frw*numVal - x;
          x = 0;
        } else {
          if (cur == 'o') {
            cellVal = 1;
          } else {
            cellVal = 0;
          }

          for (k = 0; k < numVal; k++) {
            *cellPos = cellVal;
            *colPos = col;

            x++;
            cellPos++;
            colPos++;
          }
        }
      } else {
        num[numInd] = cur;
        numInd++;
      }

      linePos++;
    }
  }

  return 0;
}

void randCells(char* destCell, double* destColor, double col)
{
  int i;
  int j;

  char* cellRow = destCell;
  char* cellPos;
  double* colorRow = destColor;
  double* colorPos;
  for (i = 0; i < gridSize; i++) {
    cellPos = cellRow;
    colorPos = colorRow;
    for (j = 0; j < gridSize; j++) {
      if ((rand()%3) == 0) {
        *cellPos = 0;
        *colorPos = 0.0;
      } else {
        *cellPos = 1;
        *colorPos = col;
      }

      cellPos++;
      colorPos++;
    }

    cellRow += gridWidth;
    colorRow += gridWidth;
  }
}

int main(int argc, char** argv)
{
  srand(time(NULL));

  int i;
  int j;
  int k;

  int vol = gridWidth*gridHeight;

  memset(cells,0,sizeof(char)*vol);
  memset(colors,0,sizeof(double)*vol);

  int ret;
  if (argc == 1) {
    randCells(cells,colors,0.0);
    randCells(cells+gridSize,colors+gridSize,1.0);
  } else if (argc == 2) {
    FILE* src = fopen(argv[1],"r");
    loadCells(src,cells,colors,gridSize,gridWidth,0.0);
    fclose(src);

    randCells(cells+gridSize,colors+gridSize,1.0);
  } else if (argc == 3) {
    FILE* src = fopen(argv[1],"r");
    loadCells(src,cells,colors,gridSize,gridWidth,0.0);
    fclose(src);

    src = fopen(argv[2],"r");
    loadCells(src,cells+gridSize,colors+gridSize,gridSize,gridWidth,1.0);
    fclose(src);
  } else {
    return 0;
  }

  mtl = (meanTrack*)malloc(sizeof(meanTrack)*meanLength);
  for (int m = 0; m < (meanLength-1); m++) {
    mtl[m].meank = 0.0;
    mtl[m].next = &(mtl[m+1]);
  }
  mtl[meanLength-1].meank = 0.0;
  mtl[meanLength-1].next = mtl;

  gtk_init(&argc, &argv);

  window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
  gtk_window_resize(GTK_WINDOW(window),width,height);
  gtk_widget_set_app_paintable(GTK_WIDGET(window),TRUE);
  gtk_widget_add_events(GTK_WIDGET(window),GDK_BUTTON_RELEASE_MASK);
  g_signal_connect(window,"expose-event",G_CALLBACK(expose_grid),NULL);
  g_signal_connect(window,"button-release-event",G_CALLBACK(togglePause),NULL);
  g_signal_connect(window,"destroy",G_CALLBACK(gtk_main_quit),NULL);
  gtk_widget_show(window);

  idleID = gtk_idle_add(next_grid,NULL);

  gdk_window_invalidate_rect(window->window,NULL,TRUE);

  gtk_main();

  return 0;
}